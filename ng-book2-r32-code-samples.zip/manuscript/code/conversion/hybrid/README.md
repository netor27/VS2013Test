# ng-book 2: ng1/ng2 hybrid example app

> This project shows how to create a hybrid ng1/ng2 app

## Quick start

```bash
# install 
npm install

# run
npm run go
```

Then visit [http://localhost:8080](http://localhost:8080) in your browser. 

## credits

* Photo's are CC. For attribution, see the sample-data.json file
* Heart Icon by Thomas Le Bas
