/*
 * Angular
 */
import {Component} from '@angular/core';

@Component({
  selector: 'sportify',
  template: `<h3>Sportify page</h3>`
})
export class SportifyComponent {
}
