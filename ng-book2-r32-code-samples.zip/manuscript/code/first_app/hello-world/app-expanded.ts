/**
 * This file shows the intermediate components in the hello-world app.
 */

import { bootstrap } from "@angular/platform-browser-dynamic";
import { Component } from "@angular/core";

@Component({
  selector: 'hello-world',
  template: `<div>Hello {{ name }}</div>`
})
class HelloWorldWithName {
  name: string;

  constructor() {
    this.name = 'Felipe';
  }
}

@Component({
  selector: 'hello-world',
  template: `
  <ul>
    <li *ngFor="let name of names">Hello {{ name }}</li>
  </ul>
`
})
class HelloWorldWithNames {
  names: string[];

  constructor() {
    this.names = ['Ari', 'Carlos', 'Felipe', 'Nate'];
  }
}

bootstrap(HelloWorldWithNames);
