export class Calculator {
  add(op1: number, op2: number){
    return op1 + op2;
  }
  subtract(op1: number, op2: number){
    return op1 - op2;
  }
}
