import {fromNowPipeInjectables} from './FromNowPipe';

export var utilInjectables: Array<any> = [
  fromNowPipeInjectables
];
