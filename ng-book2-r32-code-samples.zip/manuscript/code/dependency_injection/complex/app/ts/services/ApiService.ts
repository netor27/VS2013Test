export class ApiService {
  get(): void {
    console.log('Getting resource...');
  }
}
